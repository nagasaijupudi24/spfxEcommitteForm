declare const styles: {
    form: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    generalSectionMainContainer: string;
    generalSection: string;
    halfWidth: string;
    generalSectionContainer1: string;
    generalSectionApproverDetails: string;
    approverDetailsSection: string;
    headerContainer: string;
    headers: string;
    commonProperties: string;
    noteHeader: string;
    noteTitle: string;
    commonBtn: string;
    commonBtn1: string;
    commonBtn2: string;
    addBtn: string;
    message: string;
    warning: string;
    label: string;
    tableContainer: string;
};
export default styles;
//# sourceMappingURL=Form.module.scss.d.ts.map