import React from 'react';
interface UploadFileProps {
    typeOfDoc: string;
    onChange: (files: FileList | null, typeOfDoc: string) => void;
    accept?: string;
}
declare const UploadFileComponent: React.FC<UploadFileProps>;
export default UploadFileComponent;
//# sourceMappingURL=uploadFile.d.ts.map