import * as React from 'react';
import { IFormProps } from '../IFormProps';
import { IDropdownOption } from 'office-ui-fabric-react';
import "@pnp/sp/fields";
interface IMainFormState {
    noteTypeValue?: IDropdownOption;
    isNoteType: boolean;
    new: string;
    itemsFromSpList: any[];
    getAllDropDownOptions: any;
    natureOfNote: IDropdownOption[];
    natureOfApprovalSancation: IDropdownOption[];
    committename: string[];
    typeOfFinancialNote: IDropdownOption[];
    noteType: string[];
    isPuroposeVisable: boolean;
    isAmountVisable: boolean;
    isTypeOfFinacialNote: boolean;
    isNatureOfApprovalOrSanction: boolean;
    committeeNameFeildValue: string;
    subjectFeildValue: string;
    natureOfNoteFeildValue: string;
    noteTypeFeildValue: string;
    natureOfApprovalOrSanctionFeildValue: string;
    typeOfFinancialNoteFeildValue: string;
    searchTextFeildValue: string;
    amountFeildValue: string;
    puroposeFeildValue: string;
    notePdfFile: File | null;
    supportingFile: File | null;
    isWarning: boolean;
}
export declare const FormContext: React.Context<any>;
export default class Form extends React.Component<IFormProps, IMainFormState> {
    constructor(props: IFormProps);
    private getfield;
    componentDidMount(): void;
    private fetchListItems;
    private handleCommittename;
    private handleSubject;
    private handleNatureOfNote;
    private handleNatureOfApprovalOrSanction;
    private handleNoteType;
    private handleTypeOfFinanicalNote;
    private handleSearchText;
    private handleAmount;
    private handlePurpose;
    private handleSubmit;
    render(): React.ReactElement<IFormProps>;
}
export {};
//# sourceMappingURL=Form.d.ts.map