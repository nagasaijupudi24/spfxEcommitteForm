/* tslint:disable */
require("./Form.module.css");
const styles = {
  form: 'form_2595e25a',
  welcome: 'welcome_2595e25a',
  welcomeImage: 'welcomeImage_2595e25a',
  links: 'links_2595e25a',
  generalSectionMainContainer: 'generalSectionMainContainer_2595e25a',
  generalSection: 'generalSection_2595e25a',
  halfWidth: 'halfWidth_2595e25a',
  generalSectionContainer1: 'generalSectionContainer1_2595e25a',
  generalSectionApproverDetails: 'generalSectionApproverDetails_2595e25a',
  approverDetailsSection: 'approverDetailsSection_2595e25a',
  headerContainer: 'headerContainer_2595e25a',
  headers: 'headers_2595e25a',
  commonProperties: 'commonProperties_2595e25a',
  noteHeader: 'noteHeader_2595e25a',
  noteTitle: 'noteTitle_2595e25a',
  commonBtn: 'commonBtn_2595e25a',
  commonBtn1: 'commonBtn1_2595e25a',
  commonBtn2: 'commonBtn2_2595e25a',
  addBtn: 'addBtn_2595e25a',
  message: 'message_2595e25a',
  warning: 'warning_2595e25a',
  label: 'label_2595e25a',
  tableContainer: 'tableContainer_2595e25a'
};

export default styles;
/* tslint:enable */