/* tslint:disable */
require("./Form.module.css");
const styles = {
  form: 'form_bed21214',
  welcome: 'welcome_bed21214',
  welcomeImage: 'welcomeImage_bed21214',
  links: 'links_bed21214',
  generalSectionMainContainer: 'generalSectionMainContainer_bed21214',
  generalSection: 'generalSection_bed21214',
  generalSectionContainer1: 'generalSectionContainer1_bed21214',
  generalSectionApproverDetails: 'generalSectionApproverDetails_bed21214',
  approverDetailsSection: 'approverDetailsSection_bed21214',
  headerContainer: 'headerContainer_bed21214',
  headers: 'headers_bed21214',
  commonProperties: 'commonProperties_bed21214',
  noteHeader: 'noteHeader_bed21214',
  noteTitle: 'noteTitle_bed21214',
  commonBtn: 'commonBtn_bed21214',
  commonBtn1: 'commonBtn1_bed21214',
  commonBtn2: 'commonBtn2_bed21214',
  addBtn: 'addBtn_bed21214',
  message: 'message_bed21214',
  warning: 'warning_bed21214',
  label: 'label_bed21214',
  tableContainer: 'tableContainer_bed21214'
};

export default styles;
/* tslint:enable */