import React from 'react';
declare const SpanComponent: React.FC;
export default SpanComponent;
//# sourceMappingURL=spanComponent.d.ts.map