import React from 'react';
interface UploadFileProps {
    onChange: (files: FileList | null) => void;
    accept?: string;
}
declare const UploadFileComponent: React.FC<UploadFileProps>;
export default UploadFileComponent;
//# sourceMappingURL=uploadFile.d.ts.map