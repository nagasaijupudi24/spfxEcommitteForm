import * as React from 'react';
import type { IFormProps } from './IFormProps';
export default class Form extends React.Component<IFormProps, {}> {
    render(): React.ReactElement<IFormProps>;
}
//# sourceMappingURL=Form.d.ts.map