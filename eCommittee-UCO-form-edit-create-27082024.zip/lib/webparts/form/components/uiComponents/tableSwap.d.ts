import * as React from 'react';
declare const TableComponent: React.FC;
export default TableComponent;
//# sourceMappingURL=tableSwap.d.ts.map