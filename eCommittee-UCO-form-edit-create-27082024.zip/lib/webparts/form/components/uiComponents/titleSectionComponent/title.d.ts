import * as React from 'react';
declare const Title: React.FC;
export default Title;
//# sourceMappingURL=title.d.ts.map