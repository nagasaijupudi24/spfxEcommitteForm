/* tslint:disable */
require("./Form.module.css");
const styles = {
  form: 'form_df046317',
  welcome: 'welcome_df046317',
  welcomeImage: 'welcomeImage_df046317',
  links: 'links_df046317',
  generalSectionMainContainer: 'generalSectionMainContainer_df046317',
  generalSection: 'generalSection_df046317',
  halfWidth: 'halfWidth_df046317',
  generalSectionContainer1: 'generalSectionContainer1_df046317',
  generalSectionApproverDetails: 'generalSectionApproverDetails_df046317',
  approverDetailsSection: 'approverDetailsSection_df046317',
  headerContainer: 'headerContainer_df046317',
  headers: 'headers_df046317',
  commonProperties: 'commonProperties_df046317',
  responsiveTitle: 'responsiveTitle_df046317',
  noteHeader: 'noteHeader_df046317',
  noteTitle: 'noteTitle_df046317',
  commonBtn: 'commonBtn_df046317',
  commonBtn1: 'commonBtn1_df046317',
  commonBtn2: 'commonBtn2_df046317',
  addBtn: 'addBtn_df046317',
  message: 'message_df046317',
  warning: 'warning_df046317',
  label: 'label_df046317',
  tableContainer: 'tableContainer_df046317',
  fileInputContainers: 'fileInputContainers_df046317',
  fileAttachementsUl: 'fileAttachementsUl_df046317',
  basicLi: 'basicLi_df046317',
  inputField: 'inputField_df046317',
  attachementli: 'attachementli_df046317',
  customFileUpload: 'customFileUpload_df046317'
};

export default styles;
/* tslint:enable */