import React from 'react';
declare const AlertComponent: React.FC;
export default AlertComponent;
//# sourceMappingURL=alter.d.ts.map