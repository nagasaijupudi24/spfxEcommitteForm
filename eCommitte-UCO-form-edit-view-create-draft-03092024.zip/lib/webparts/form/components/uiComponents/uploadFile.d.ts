import React from "react";
interface UploadFileProps {
    typeOfDoc: string;
    onChange: (files: File[] | null, typeOfDoc: string) => void;
    accept?: string;
    maxFileSizeMB: number;
    multiple: boolean;
    maxTotalSizeMB?: number;
    data: File[];
}
declare const UploadFileComponent: React.FC<UploadFileProps>;
export default UploadFileComponent;
//# sourceMappingURL=uploadFile.d.ts.map