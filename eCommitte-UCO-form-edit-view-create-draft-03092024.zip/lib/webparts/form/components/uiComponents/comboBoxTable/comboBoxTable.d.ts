import * as React from 'react';
interface IState {
    items: any[];
    selectedItem: any;
    columns: any[];
}
export default class MultiColumnComboBoxComponent extends React.Component<{}, IState> {
    constructor(props: {});
    handleChange: (event: any) => void;
    handleAddItem: () => void;
    handleRemoveItem: (id: number) => void;
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=comboBoxTable.d.ts.map