import * as React from 'react';
interface TitleProps {
    formStatus: string;
}
declare const Title: React.FC<TitleProps>;
export default Title;
//# sourceMappingURL=title.d.ts.map