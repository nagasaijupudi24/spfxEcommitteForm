import * as React from 'react';
declare const Header: React.FC;
export default Header;
//# sourceMappingURL=header.d.ts.map