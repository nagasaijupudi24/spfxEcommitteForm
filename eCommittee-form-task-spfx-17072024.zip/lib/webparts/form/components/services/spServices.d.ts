import { WebPartContext } from "@microsoft/sp-webpart-base";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/views";
import "@pnp/sp/items/get-all";
import "@pnp/sp/files";
import "@pnp/sp/folders";
export default class spService {
    private context;
    private _sp;
    constructor(context: WebPartContext);
    getfieldDetails: (listName: string) => Promise<{
        key?: string;
        text?: string;
        dataType: string;
        option?: string[];
        internalName: string;
    }[]>;
}
//# sourceMappingURL=spServices.d.ts.map