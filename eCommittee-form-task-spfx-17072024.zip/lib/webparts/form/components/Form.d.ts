import * as React from 'react';
import { IFormProps } from './IFormProps';
import { IDropdownOption } from 'office-ui-fabric-react';
import "@pnp/sp/fields";
interface IMainFormState {
    noteTypeValue?: IDropdownOption;
    isNoteType: boolean;
    new: string;
    itemsFromSpList: any[];
    getAllDropDownOptions: any;
}
export declare const FormContext: React.Context<any>;
export default class Form extends React.Component<IFormProps, IMainFormState> {
    constructor(props: IFormProps);
    private getfield;
    componentDidMount(): void;
    private fetchListItems;
    private handleDropdownChange;
    render(): React.ReactElement<IFormProps>;
}
export {};
//# sourceMappingURL=Form.d.ts.map