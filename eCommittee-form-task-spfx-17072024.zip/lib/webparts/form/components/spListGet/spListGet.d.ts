import * as React from 'react';
import { IFormProps } from '../IFormProps';
export interface IFormState {
    items: any[];
}
export default class GetForm extends React.Component<IFormProps, IFormState> {
    constructor(props: IFormProps);
    componentDidMount(): void;
    private fetchListItems;
    render(): React.ReactElement<IFormProps>;
}
//# sourceMappingURL=spListGet.d.ts.map